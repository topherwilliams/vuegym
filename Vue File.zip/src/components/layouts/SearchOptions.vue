<template>
    <form id="classSearchForm">
        <div id="classSearchFormFields">
            <div class="formControlGroup">
                <label class="formControlLabel" for="className">Class Name</label>
                <input v-model="searchTerm" class="formControls" name="className" type="text"/>
            </div>
            <div class="formControlGroup">
                <label class="formControlLabel" for="instructorName">Instructor Name</label>
                <input v-model="searchTermInstructor" class="formControls" name="className" type="text"/>
            </div>
        </div>
        <div class="formControlGroup formControlButton" style="padding-top: 30px;">
            <div>
                <base-button @confirmAction="commitSearch" :buttonInfo="searchButtonInfo"></base-button>
            </div>
        </div>
    </form>
</template>

<script>

export default {
    props: ['searchButtonInfo'],
    data() {
        return {
            searchTerm: '',
            searchTermInstructor: '',
        }
    },
    methods: {
        commitSearch() {
            this.$emit('commitSearch', this.searchTerms);
            this.searchTerm = '';
            this.searchTermInstructor = '';
        }
    },
    computed: {
        searchTerms() {
            return {
                className: this.searchTerm,
                instructorName: this.searchTermInstructor
            }
        }
    }
}

</script>

<style scoped>
h2 {
    width:100%;
    text-align: center;    
}

#classSearch {
    display: flex;
    justify-content: center;
    margin: 15px 0px;
}

#classSearchForm {
    min-width: 320px;
    width: 1200px;
    padding: 20px;
    display: flex;
    flex-direction: column;
}

#classSearchFormFields {
    display: flex;
    flex-direction: row;
    justify-content: center;
    
}

.formControlGroup {
    margin-bottom: 10px;
    margin-left: 30px;
    margin-right: 30px;
    max-width: 50%;
    justify-content: center;
    vertical-align: middle; 
}

.formControlButton {
    align-self: center;
}

.formControls {
    border-radius: 3px;
    font-size: 1.1rem;
}

.formControlLabel{
    padding-right: 30px;
}
</style>