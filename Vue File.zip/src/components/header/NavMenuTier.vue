<template>
    <div class="menu" :class="menuLevel">
        <ul>
            <li v-for="item in items" @click="setActiveMenuItem(item)" :class="item === activeMenuItem? 'active': ''" :key="item">{{ item }}</li>
        </ul>
    </div>
</template>

<script>

export default {
    props: ['items', 'level'],
    data() {
        return {
            menuLevel: null,
            activeMenuItem: '',
        }
    },
    methods: {
        setActiveMenuItem(item) {
            this.activeMenuItem = item;
            if (this.level === "tier_1") {
                // Ie upper level
                this.$emit('changeActiveMenuOption', this.activeMenuItem);
            } else {
                // Ie set route for actual app router.
                this.$emit('changeSecondTierMenuOption', this.activeMenuItem);
            }
        }
    },  
    created(){
        this.menuLevel = this.level;
    }


}
</script>

<style scoped>
.menu {
    font-family: 'Permanent Marker', cursive;
}

.tier_1 {
    margin-top:auto;
    margin-bottom: auto;
    margin-left: 35px;
    font-size: 2.3rem;
}

.tier_2 {
    padding-top: 10px;
    padding-bottom: 10px;
    font-size: 1.8rem;
    border-bottom: 1px solid black;
}

ul {
    /* width: 100%; */
    margin-top: 0;
    margin-bottom: 0;
    padding: 0;
    list-style: none;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: space-evenly;

}

li {
    text-decoration: none;
    padding-right: 35px;
}

.tier_2 li{
    padding-right: 0;
}


li:hover{
    /* font-size: 2.4rem; */
    /* To be done */
}

li.active {
    /* Change colour or something here to make it clear which option the user is on  */
}



</style>