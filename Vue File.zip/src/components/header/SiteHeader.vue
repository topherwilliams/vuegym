<template>
    <header>
        <nav>
            <div id="menuTier1">
                <div id="logo-container">
                    <i class="fas fa-dumbbell fa-3x"></i>
                    <h1>Vue Gym</h1>
                </div>    
                <NavMenu :items="levelOneMenuOptions" level="tier_1" @changeActiveMenuOption="updateTier2"></NavMenu>
                <div id="authentication-actions-container">
                    <div id="authentication-action-container">
                        <i class="fas fa-sign-in-alt fa-2x"></i>
                        <p>Login</p>
                    </div>  
                    <div id="authentication-action-container">
                        <i class="fas fa-sign-out-alt fa-2x"></i>
                        <p>Logout</p>
                    </div>    
                </div>  
            </div>
            <transition name="menuLevel2DropDown">
                <NavMenu v-if="secondTierAvailable" @changeSecondTierMenuOption="confirmTier2" :items="availableLevelTwoMenuOptions" level="tier_2"></NavMenu>
            </transition>
        </nav>
    </header>
</template>


<script>
import NavMenu from './NavMenuTier.vue';
//import { useRoute } from 'vue-router';

export default {
    components: {
        NavMenu,
    },
    data() {
        return {
            levelOneMenuOptions: ['My Dashboard', 'Classes', 'Workouts'],
            selectedLevelOneMenuOption: null,
            levelTwoMenuOptions: {
                classes: ['My Class Schedule', 'Vue Gym Class Calender', 'Search Classes'],
                workouts: ['My Workouts', 'Progress Tracker'],
            },
            urls: {
                mydashboard: '/dashboard',
                myclassschedule: '/myclassschedule',
                vuegymclasscalender: '/classcalender',
                searchclasses: '/classsearch',
                myworkouts: '/myworkouts',
                progresstracker: '/progresstracker',
            },
            availableLevelTwoMenuOptions: [],
        }
    },
    computed: {
        secondTierAvailable() {
            if (this.availableLevelTwoMenuOptions.length < 1) {
                return false;
            } else {
                return true;
            }
        }
    },
    methods: {
        confirmTier2(selectedTier2Item) {
            const parsedString = selectedTier2Item.toLowerCase().replaceAll(' ', '');
            this.$router.push(this.urls[parsedString]);
        },
        updateTier2(selectedTopLevelMenuOption) {
            const topLevelMenuOption = selectedTopLevelMenuOption.toLowerCase();
            this.selectedLevelOneMenuOption = topLevelMenuOption;
            if (topLevelMenuOption === "my dashboard") {
                this.availableLevelTwoMenuOptions = [];
                this.$router.push(this.urls['mydashboard']);
            } else {
                this.availableLevelTwoMenuOptions = [...this.levelTwoMenuOptions[topLevelMenuOption]];
            }
        }
    },
    // created() {
    //     console.log(useRoute().name);
    // }
}
</script>

<style scoped>
#menuTier1 {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    width: 100%;
    border-bottom: 1px black solid;
};

nav {
    padding: 8px;
}

#logo-container, #authentication-action-container {
    padding: 8px 15px;
    text-align: center;
}

#logo-container h1 {
    margin: 2px 0px 5px 0px;
    text-align: center;
    font-family: 'Permanent Marker', cursive;
    font-size: 2rem;
}

#authentication-actions-container {
    margin-top: auto;
    margin-bottom: auto;
    margin-left:auto;
    display:flex;
}

#authentication-action-container {
    margin-top: auto;
    margin-bottom: auto;
    margin-left: auto;
}

#authentication-action-container p {
    margin: 2px 0px 5px 0px;
    text-align: center;
    font-size: 0.8rem;
}

.menuLevel2DropDown-enter-from, .menuLevel2DropDown-leave-to {
    opacity: 0;
    transform: translateY(-40px);
}

.menuLevel2DropDown-enter-active, .menuLevel2DropDown-leave-active {
    transition: all 0.9s;
}

.menuLevel2DropDown-enter-to, .menuLevel2DropDown-leave-from {
    opacity: 1;
    transform: translateY(0px);
}



</style>