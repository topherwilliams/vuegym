<template>
    <Transition name="slideUp">
        <div v-if="workoutAvailable" id="workoutEditContainer">
            <div id="workoutEditHeader">
                <h2>Edit Workout {{ workoutInfo.workout_id }}</h2>
                <i @click="this.$emit('closeEditWorkout')" class="fas fa-times"></i>
            </div>
            <div id="addExercise">
                <div id="addExerciseHeader" @click="toggleAddExercise">
                    <h3>Add exercise to workout</h3>
                </div>
                <keep-alive>
                    <SetExercise componentContext="add" @commitNewExercise="commitAddExercise" v-if="settingNewExercise"></SetExercise>
                </keep-alive>
            </div>
            <WorkoutExerciseList :exerciseList="getExercises" @commitEditExercise="commitEditExercise" @commitDeleteExercise="commitDeleteExercise"></WorkoutExerciseList>
        </div>
    </Transition>
</template>

<script>
import SetExercise from './SetExercise.vue';
import WorkoutExerciseList from './WorkoutExerciseList.vue';

export default {
    components: {
        SetExercise,
        WorkoutExerciseList
    },
    data() {
        return {
            settingNewExercise: false
        }
    },
    props: ['workoutInfo'],
    computed: {
        workoutAvailable() {
            if(this.workoutInfo) {
                return true;
            } else {
                return false;
            }
        },
        getExercises() {
            return [...this.workoutInfo.exercises];
        }
    },
    methods: {
        commitDeleteExercise(payload) {
            const tempAmendedWorkout = this.workoutInfo;
            tempAmendedWorkout.exercises = this.filterExerciseListToRemoveTargetExercise(payload, tempAmendedWorkout.exercises);
            console.log(tempAmendedWorkout.exercises);
            this.$store.dispatch('updateWorkout', tempAmendedWorkout);
        },
        commitEditExercise(payload) {
            const tempAmendedWorkout = this.workoutInfo;
            tempAmendedWorkout.exercises = [...tempAmendedWorkout.exercises.filter((exercise) => {
                if (exercise.exercise_id !== payload.exercise_id) {
                    return true;
                } 
            })];
            tempAmendedWorkout.exercises.push(payload);
            this.$store.dispatch('updateWorkout', tempAmendedWorkout);
        },
        commitAddExercise(payload) {
            // In reality - API call and then refresh store data.
            const tempAmendedWorkout = this.workoutInfo;
            const tempExercise = payload;
            if (!tempExercise.exercise_id) {
                tempExercise.exercise_id = new Date().toISOString();
            }
            tempAmendedWorkout.exercises.push(tempExercise);
            this.$store.dispatch('updateWorkout', tempAmendedWorkout);
            this.settingNewExercise = false;
        },
        toggleAddExercise() {
            this.settingNewExercise = !this.settingNewExercise;
        },
        filterExerciseListToRemoveTargetExercise(id, exercises) {
            const exercisesToReturn = exercises.filter((exercise) => {
                if (exercise.exercise_id !== id) {
                    return true;
                }
            });
            return exercisesToReturn;
        }
    },
    created() {
        
    }
}
</script>

<style scoped>
#workoutEditHeader {
    display: flex;
    align-items: center;
    padding: 0 20px;
}

.fas {
    padding: auto;
    text-align: center;
    justify-content: center;
}

.fas:hover {
    cursor: pointer;
    transform: scale(1.4);
}


h2 {
    margin: 15px auto;

    /* align-self: center;
    text-align: center; */
}
#workoutEditContainer {
    width: 100%;
    height: 100%;
    /* overflow-y: auto; */
}

#workoutDetails {
    width: 100%;

}

#addExercise {
    min-width: 320px;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
    border: 0.5px solid grey;
    border-radius: 12px;
}

#addExerciseHeader:hover {
    cursor: pointer;
}

#addExerciseHeader {
    display:flex;
    justify-content: center;
    align-items: center;
}

.fa-plus {
    margin-right: 15px;
}

.slideUp-enter-from, .slideUp-leave-to {
    opacity: 0;
    transform: translateY(50px);
}

.slideUp-enter-to, .slideUp-leave-from {
    opacity: 1;
    transform: translateY(0);
}

.slideUp-enter-active, .slideUp-leave-active {
    transition: all 1s;
}


</style>