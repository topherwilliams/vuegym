<template>
    <div :class="classType" class="exerciseContainer">
        <form class="exerciseForm">
            <div class="formControlGroup">
                <span class="labelSpan">
                    <label for="exerciseSelection" class="formControlLabel">Exercise Name </label>
                </span>
                <span>
                    <select v-model="exerciseName" name="exerciseSelection" id="exerciseSelection" class="formControls">
                        <option v-for="exercise in exerciseList" :key="exercise" :value="exercise">{{exercise}}</option>
                    </select>
                </span>
            </div>
            <div class="formControlGroup">
                <span class="labelSpan">
                    <label for="exerciseWeightSelection" class="formControlLabel">Weight (kg) </label>
                </span>
                <span>
                    <input v-model="exerciseWeight" name="exerciseWeightSelection" id="exerciseWeightSelection" type="number" min=1 class="formControls"/>
                </span>
            </div>
            <div class="formControlGroup">
                <span class="labelSpan">
                    <label for="exerciseRepSelection" class="formControlLabel">Repetitions </label>
                </span>
                <span>
                    <input v-model="exerciseReps" name="exerciseRepSelection" id="exerciseRepSelection" type="number" min=1 class="formControls"/>
                </span>
            </div>
            <div class="formControlGroup">
                <span class="labelSpan">
                    <label for="exerciseSetSelection" class="formControlLabel">Sets </label>
                </span>
                <span>
                    <input v-model="exerciseSets" name="exerciseSetSelection" id="exerciseSetSelection" type="number" min=1 class="formControls"/>
                </span>
            </div>
        </form>
        <div class="formSubmitControls">
            <i @click="submitExercise" :class="commitIconClass"></i>
        </div>
    </div>
</template>

<script>

export default {
    props: ['componentContext', 'existingExercise'],
    data() {
        return {
            exercise_id: null,
            exerciseName: '',
            exerciseReps: 0,
            exerciseSets: 0,
            exerciseWeight: 0,

        }
    },
    computed: {
        classType() {
            if (this.componentContext === 'add') {
                return 'addExercise';
            } else {
                return 'editExcercise';
            }
        },
        commitIconClass() {
            if(this.componentContext === 'add') {
                return "fas fa-plus";
            } else {
                return "fas fa-save";
            }
        },
        commitType() {
            if (this.componentContext === 'add') {
                return 'commitNewExercise';
            } else {
                return 'commitEditExercise';
            }
        },
        exerciseList() {
            return this.$store.getters.sortedExerciseList;
        }
    },
    methods: {
        submitExercise() {
            if (this.exerciseName != '' && this.exerciseWeight != 0 & this.exerciseReps !=0) {
                // Only submit if details entered
                const tempExercise = {
                    exercise_id: this.exercise_id,
                    exercise_name: this.exerciseName,
                    reps: this.exerciseReps,
                    sets: this.exerciseSets,
                    weight_kg: this.exerciseWeight,
                }
                this.$emit(this.commitType, tempExercise);
                if (this.componentContext === 'add') {
                    this.clearExerciseDetails();
                }
            } else {
                // Error handling in here.
                console.log("Unable to submit...");
            } 
        },
        clearExerciseDetails() {
            this.exerciseName = '';
            this.exerciseReps = 0;
            this.exerciseWeight = 0;
            this.exerciseSets = 0;
        }
    },
    created() {
        if (this.componentContext === 'edit') {
            // WILL NEED AMENDING - ESSENTIALLY CHECKS IF EDITING AND IF SO POPULATES THE DROP DOWN WITH THE EXERCISE NAME.
            this.exercise_id = this.existingExercise.exercise_id;
            this.exerciseName = this.existingExercise.exercise_name;
            this.exerciseReps = this.existingExercise.reps;
            this.exerciseSets = this.existingExercise.sets;
            this.exerciseWeight = this.existingExercise.weight_kg;
        }
    }
}
</script>


<style scoped>
.formSubmitControls{
    display: flex;
    justify-content: end;
    padding: 10px 20px;
}

.fas:hover {
    cursor: pointer;
    transform: scale(1.4);
}

.exerciseForm {
    margin-top: 20px;
}

.exerciseContainer {
    border-top: 0.2px solid grey;
}

.labelSpan {
    width: 40%;
    text-align: end;
    margin-right: 30px;
}

.formControlGroup {
    margin: 15px 0px;
    /* margin-left: 30px;
    margin-right: 30px; */
    display: flex;
    align-items: center;
    /* justify-content: center; */
}

.formControlButton {
    align-self: center;
}

.formControls {
    /* border-radius: 3px; */
    font-size: 1rem;
    width: 200px;
}

.formControlLabel{
    /* padding-right: 30px; */
}

</style>