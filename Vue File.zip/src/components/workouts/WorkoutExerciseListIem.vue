<template>
    <div class="workoutExerciseItem" >
        <div class="workoutExerciseItemHeader" @click="toggleEditExercise">
            <h3>{{ exerciseInfo.exercise_name }}</h3>
            <p>{{ exerciseInfo.weight_kg }}kg x {{ exerciseInfo.reps }} x {{ exerciseInfo.sets }}</p>
            <span class="listOptions">
                <!-- <div class="listOption" @click="toggleEditExercise">
                    <i class="fas fa-edit"></i>
                </div> -->
                <div class="listOption" @click="deleteExercise">
                    <i class="fas fa-trash"></i>
                </div>
            </span>
        </div>
        <keep-alive>
            <SetExercise v-if="editingExercise" @commitEditExercise="commitEditExercise" componentContext="edit" :existingExercise="exerciseInfo"></SetExercise>
        </keep-alive>
    </div>
</template>

<script>
import SetExercise from './SetExercise.vue';
export default {
    components: {
        SetExercise
    },  
    props: ['exerciseInfo'],
    data() {
        return {
            editingExercise: false,
        }
    },
    methods: {
        commitEditExercise(payload) {
            this.$emit('commitEditExercise', payload);
        },
        toggleEditExercise() {
            this.editingExercise = !this.editingExercise;
        },
        deleteExercise() {
            this.$emit('deleteExercise', this.exerciseInfo.exercise_id);
        }
    },
    created() {
        
    }
}
</script>

<style scoped>
h3 {
    width: 100%;
}

p{
    width: 100%;
    text-align: start;
}

.listOptions{
    display: flex;
    align-items: flex-end;
    margin-right: 10px;
}

.listOption {
    width: 100%;
    display: flex;
    align-items: center;
}

.listOption:hover {
    cursor: pointer;
}

.listOption:not(:last-child) {
    margin-right: 30px;
}

.workoutExerciseItem {
    min-width: 320px;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 20px;
    border: 0.5px solid grey;
    border-radius: 12px;
}

.workoutExerciseItemHeader {
    display:flex;
    justify-content:flex-end;
    align-items: center;
    padding: 10px;
}
</style>