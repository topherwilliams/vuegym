<template>
    <div id="workoutList-Container">
        <div id="workoutList" v-if="workoutsAvailable">
            <DetailedWorkoutListItem v-for="listItem in workoutList" :workoutInfo="listItem" :key="listItem.workout_id" @selectWorkout="selectWorkout" @deleteWorkout="deleteWorkout"></DetailedWorkoutListItem>
        </div>
        <div v-else>
            <p>You have no workouts logged.</p>
        </div>
    </div>
</template>

<script>
import DetailedWorkoutListItem from './DetailedWorkoutListItem.vue';

export default {
    components: {
        DetailedWorkoutListItem
    },
    props: ['workouts', 'selectedWorkout'],
    computed: {
        workoutsAvailable() {
            if (this.workouts.length < 1) {
                return false;
            } else {
                return true;
            }
        },
        workoutList() {
            if (!this.selectedWorkout) {
                return [...this.workouts];
            } else {
                return [...this.workouts.filter((workout) => {
                    if(workout.workout_id === this.selectedWorkout.workout_id) {
                        return true;
                    }
                })]
            }
        }
    },
    methods: {
        deleteWorkout(id) {
            this.$emit('deleteWorkout', id);
        },
        selectWorkout(id) {
            this.$emit('selectWorkout', id);
        }  
    }
}
</script>

<style scoped>
h2, p {
    width: 100%;
    text-align: center;
}
#workoutList-Container {
    padding-top: 10px;
    width: 100%;
    align-items: center;
    background-color: lightgray;
}

#workoutList {
    align-self: center;
    margin-left: auto;
    margin-right: auto;
    padding: 10px 0px;
}

</style>