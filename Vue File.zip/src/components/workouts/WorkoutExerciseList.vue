<template>
    <div id="exerciseList">
        <div v-if="!exercisesInWorkout">
            <p>There are no exercises registered on this workout yet.</p>
        </div>
        <WorkoutExerciseListIem v-else v-for="exercise in exerciseList" :key="exercise.exercise_name" :exerciseInfo="exercise" @deleteExercise="commitDeleteExercise" @commitEditExercise="commitEditExercise"></WorkoutExerciseListIem>
    </div>
</template>

<script>
import WorkoutExerciseListIem from './WorkoutExerciseListIem.vue';

export default {
    components: {
    WorkoutExerciseListIem,
},
    props: ['exerciseList'],
    computed: {
        exercisesInWorkout() {
            return this.exerciseList.length < 1? false : true;
        }
    },
    methods: {
        commitDeleteExercise(payload) {
            this.$emit('commitDeleteExercise', payload)
        },
        commitEditExercise(payload) {
            this.$emit('commitEditExercise', payload);
        },
    },
    created() {
        
    }
}
</script>

<style scoped>
#exerciseList {
    margin-top: 20px;
}
p{
    width: 100%;
    align-self: center;
    text-align: center;
    color: red;
}
</style>