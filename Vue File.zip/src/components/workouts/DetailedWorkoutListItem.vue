<template>
    <div class="workoutInformation" @click="this.$emit('selectWorkout', workoutInfo.workout_id)">
        <div class="workoutInfoHeader">
            <h3>Workout {{ workoutInfo.workout_id }}</h3>
            <p>{{ totalWorkoutEffort }}kg Total Effort</p>
            <span class="listOptions">
                <!-- <div class="listOption" @click="this.$emit('selectWorkout', workoutInfo.workout_id)" >
                    <p class="listOptionLabel">Edit</p>
                    <i class="fas fa-edit"></i>
                </div> -->
                <div class="listOption" @click="this.$emit('deleteWorkout', workoutInfo.workout_id)">
                    <i class="fas fa-trash"></i>
                </div>
            </span>
        </div>
    </div>
</template>

<script>

export default {
    components: {

    },
    props: ['workoutInfo'],
    computed: {
        totalWorkoutEffort() {
            let totalEffort = 0;
            this.workoutInfo.exercises.forEach(element => totalEffort += (element.weight_kg * element.reps * element.sets));
            return totalEffort;
        }
    },
    methods:{
    
    }
}
</script>

<style scoped>

.listOptionLabel {
    padding-right: 5px;
}

.listOption {
    width: 100%;
    display: flex;
    align-items: center;
}

.listOption:hover {
    cursor: pointer;
}

.listOption:not(:last-child) {
    margin-right: 20px;
}


.listOptions{
    display: flex;
    align-items: flex-end;
}
h3 {
    margin: 0;
    margin-top: auto;
    margin-bottom:auto;
    width: 100%;
}

p{
    width: 100%;
    text-align: start;
}

.fas {
    padding-right: 20px;
}

.workoutInformation:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 5px 5px rgba(0,0,0,0.2);
}

.workoutInformation:active {
    transform: translateY(1px);
    box-shadow: 0 2px 2px 2px rgba(0,0,0,0.5);
}

.workoutInformation {
    min-width: 320px;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 20px;
    border: 0.5px solid grey;
    border-radius: 12px;
}

.workoutInfoHeader{
    display:flex;
    justify-content:flex-end;
    align-items: center;
    padding: 10px;
}

.class-date-and-name {
    width: 70%;
    display: flex;
    justify-content: space-between;
}

.class-date{
    width: 100%;
    text-align: start;
}

.class-name {
    /* padding-right: 20px; */
}
</style>