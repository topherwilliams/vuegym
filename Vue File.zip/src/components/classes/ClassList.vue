<template>
    <div id="classList-Container">
        <h2>Class List for {{ targetDateFormatted }}</h2>
        <p>Click on any class to see more information and book / cancel a booking.</p>
        <div id="classList">
            <ClassListItem @selectClass="selectClass" v-for="classItem in classesList" :key="classItem.class_id" :classInfo="classItem"></ClassListItem>
        </div>
    </div>
</template>

<script>
import ClassListItem from './ClassListItem.vue';

export default {
    components: {
    ClassListItem,
    },
    props: ['classes', 'targetDate', 'targetDateFormatted'],
    computed: {
        classesList() {
            return [...this.classes];
        }
    },
    methods: {
        selectClass(classID) {
            this.$emit('selectClass', classID);
        }
    }
}
</script>

<style scoped>
h2, p {
    width: 100%;
    text-align: center;
}
#classList-Container {
    padding-top: 10px;
    width: 100%;
    align-items: center;
    background-color: lightgray;
}

#classList {
    align-self: center;
    margin-left: auto;
    margin-right: auto;
    padding-bottom: 20px;
}

</style>