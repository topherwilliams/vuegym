<template>
    <div id="classList-Container">
        <div id="classList" v-if="classesAvailable">
            <DetailedClassListItem v-for="listItem in classes" :classInfo="listItem" :key="listItem.class_information.class_id"></DetailedClassListItem>
        </div>
        <div v-else>
            <p>You have no upcoming classes booked.</p>
        </div>
    </div>
</template>

<script>
import DetailedClassListItem from './DetailedClassListItem.vue';


export default {
    components: {
    DetailedClassListItem,
},
    props: ['classes'],
    computed: {
        classesAvailable() {
            if (this.classesList.length < 1) {
                return false;
            } else {
                return true;
            }
        },
        classesList() {
            return [...this.classes];
        }
    },
    methods: {
        
    }
}
</script>

<style scoped>
h2, p {
    width: 100%;
    text-align: center;
}
#classList-Container {
    padding-top: 10px;
    width: 100%;
    align-items: center;
    background-color: lightgray;
}

#classList {
    align-self: center;
    margin-left: auto;
    margin-right: auto;
    padding-bottom: 20px;
}

</style>