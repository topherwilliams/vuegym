<template>
    <div id="class-booking-options">
        <div :id="optionType.idName" class="booking-options">
            <p>{{ optionType.textCopy }}</p>
            <div class="button-container-booking-options">
                <base-button @confirmAction="confirmAction" v-if="optionType.buttonInfo" :buttonInfo="optionType.buttonInfo"></base-button>
            </div>
        </div>
    </div>
</template>

<script>

export default {
    props: ['alreadyBooked', 'bookingPossible', 'classID'],
    computed: {
        classId() {
            return this.classID;
        },
        optionType() {
            if (this.alreadyBooked) {
                return {
                    idName: 'already-booked-options',
                    textCopy: 'You are already booked onto this class. To cancel, click the button below.',
                    buttonInfo: {
                        id: this.classID,
                        buttonCaption: 'Cancel Booking',
                        classType: 'cancel-button'
                    }
                }
            } else if (this.bookingPossible) {
                return {
                    idName: 'not-already-booked-options',
                    textCopy: 'You can book onto this class if you want!!',
                    buttonInfo: {
                        id: this.classID,
                        buttonCaption: 'Book Class',
                        classType: 'book-button'
                    }
                }
            } else {
                return {
                    idName: 'unable-to-book',
                    textCopy: 'Sorry! You are not currently able to book this class.',
                    buttonInfo: null,
                }
            }
        },
    },
    methods: {
        confirmAction() {
            if(this.optionType.idName === 'already-booked-options') {
                // Cancel action
                this.$store.dispatch('cancelClassBookingByClassID', this.classID);
            } else {
                // Move this out of here if it works as will be used in multiple places.
                this.$store.dispatch('bookClass', this.classID);
            }
        }
    }
}
</script>

<style scoped>
p {
    margin-top: 0px;
}

#class-booking-options {
    /* padding: 10px; */
    /* border: black solid 1px;
    border-radius: 15px; */
}

.booking-options {
    padding: 10px;
}

.button-container-booking-options {
    display: flex;
    flex-direction: row;
    justify-content: start;
}
</style>