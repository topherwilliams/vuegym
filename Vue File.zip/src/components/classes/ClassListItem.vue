<template>
    <div class="classInformation">
        <h3 @click="$emit('selectClass', classInfo.class_id)">{{classInfo.class_name}}</h3>
    </div>
</template>

<script>

export default {
    props: ['classInfo'],

}
</script>

<style scoped>
h3 {
    margin: 0;
}

h3:hover {
    cursor: pointer;
}


.classInformation {
    padding: 2px;
    margin: 5px auto;
    align-self: center;
    text-align: center;
}

</style>