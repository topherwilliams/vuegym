<template>
    <div>
        <h2>{{ classInfo[0].class_name }} Class Information</h2>
        <div id="classInformation">
            <div id="class-information-detail">
                <p>Class Duration: {{ classInfo[0].class_duration }} minutes</p>
                <p>Class Size: {{ classInfo[0].class_capacity }}</p>
                <p>Spaces Remaining: {{ remainingSpaces }}</p>
                <p>Instructor: {{ classInfo[0].class_instructor.instructor_name }}</p>
            </div>
            <div id="class-booking-information">
                <ClassBookingOptions :classID="classInfo[0].class_id" :alreadyBooked="alreadyBooked" :bookingPossible="bookingPossible"></ClassBookingOptions>
            </div>
        </div>
    </div>
</template>

<script>
import ClassBookingOptions from './ClassBookingOptions.vue';

export default {
    components: {
    ClassBookingOptions,

},
    props: ['classInfo', 'booking-info'],
    computed: {
        remainingSpaces() {
            return this.classInfo[0].class_capacity - this.classInfo[0].class_booked_spaces;
        },
        alreadyBooked() {
            const matchingClassBookings = [...this.$store.getters.returnAllClassBookings].filter((booking) => {
                return booking.class_information.class_id === this.classInfo[0].class_id? true : false;
            })
            return matchingClassBookings.length < 1 ? false : true;
        },
        bookingPossible() {
            if (!this.alreadyBooked && this.remainingSpaces > 0) {
                return true;
            } else {
                return false;
            }
        }
    },
}
</script>

<style scoped>
h2 {
    text-align: center;
}

#classInformation {
    display: flex;
    flex-direction: row;
}

#class-information-detail {
    width: 45%;
    padding-right: 30px;
    text-align: end;
}

#class-booking-information {
    padding-left: 30px;
}

</style>