<template>
    <div class="classInformation">
        <div class="class-info-header">
            <!-- <div class="class-date-and-name"> -->
                <h3 class="class-date">{{ readableClassDate }}</h3>
                <h3 class="class-name">{{ classInfo.class_information.class_name }}</h3>
            <!-- </div> -->
            <!-- TODO - dynamic button dependent on whether class is booked or not -->
            <Base-button :bookingPossible="bookingPossible" @click="confirmAction" :buttonInfo="buttonInfo"></Base-button>
        </div>
    </div>
</template>

<script>
import BaseButton from '../ui/BaseButton.vue';
export default {
    components: {
        BaseButton
    },
    props: ['classInfo',],
    computed: {
        remainingSpaces() {
            return this.classInfo.class_information.class_capacity - this.classInfo.class_information.class_booked_spaces;
        },
        alreadyBooked() {
            const matchingClassBookings = [...this.$store.getters.returnAllClassBookings].filter((booking) => {
                return booking.class_information.class_id === this.classInfo.class_information.class_id? true : false;
            })
            return matchingClassBookings.length < 1 ? false : true;
        },
        bookingPossible() {
            if (!this.alreadyBooked && this.remainingSpaces > 0) {
                return true;
            } else {
                return false;
            }
        },
        buttonInfo() {
            if (this.bookingPossible) {
                // ie not already booked
                return {
                    id: this.classInfo.class_information.class_id,
                    buttonCaption: 'Book Class',
                    classType: 'book-button'
                }
            } else {
                return {
                    id: this.classInfo.class_information.class_id,
                    buttonCaption: 'Cancel Booking',
                    classType: 'cancel-button'    
                }
            }
        },
        readableClassDate() {
            const date = new Date(this.classInfo.class_information.class_date);
            return date.toLocaleDateString("en-UK", {
                day: "numeric",
                month: "long",
                year: "numeric",
                weekday: "long"
            })
        }
    },
    methods:{
        confirmAction() {
            if (this.bookingPossible) {
                this.bookClass()
            } else {
                this.cancelClass();
            }
        },
        cancelClass() {
            this.$store.dispatch('cancelClassBookingByClassID', this.classInfo.class_information.class_id);
        },
        bookClass() {
            this.$store.dispatch('bookClass', this.classInfo.class_information.class_id);
        }
    },
    created() {
    }
}
</script>

<style scoped>
h3 {
    margin: 0;
    margin-top: auto;
    margin-bottom:auto;
}

/* h3:hover {
    cursor: pointer;
} */

.classInformation {
    padding: 10px;
    margin: 10px auto;
    min-width: 300px;
    max-width: 800px;
    align-self: center;
    text-align: center;
    border: 0.5px solid grey;
    border-radius: 8px;
}

.class-info-header{
    display:flex;
    flex-direction: row;
    justify-content: space-between;
}

.class-date-and-name {
    width: 70%;
    display: flex;
    justify-content: space-between;
}

.class-date{
    width: 35%;
    text-align: start;
}

.class-name {
    /* padding-right: 20px; */
}
</style>