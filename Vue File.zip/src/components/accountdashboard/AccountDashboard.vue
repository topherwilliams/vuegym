<template>
    <form id="dashboardForm">
        <div class="formControlGroup">
            <div class="formControlLabelContainer">
                <label for="userName">User Name: </label>
            </div>
            <div class="formControlInputContainer">
                <input v-model="userName" type="text" class="formControls" name="userName" id="userName"/>
            </div>
        </div>
        <div class="formControlGroup">
            <div class="formControlLabelContainer">
                <label for="memberName">Member Name: </label>
            </div>
            <div class="formControlInputContainer">
                <input v-model="memberName" type="text" class="formControls" name="memberName" id="memberName"/>
            </div>
        </div>
        <div class="formControlGroup">
            <div class="formControlLabelContainer">
                <label for="emailAddress">Email Address: </label>
            </div>
            <div class="formControlInputContainer">
                <input v-model="emailAddress" type="text" class="formControls" name="emailAddress" id="emailAddress"/>
            </div>
        </div>
        <div v-if="formError">
            <p class="errorText">There is a problem with this information. Cannot save in this format.</p>
        </div>
        <div id="dashboardFormFooter">
            <base-button @confirmAction="updateDetails" :buttonInfo="buttonInfo"></base-button>
        </div>
    </form>
</template>

<script>

export default {
    data() {
        return {
            userName: '',
            memberName: '',
            emailAddress: '',
            formError: false,
        }
    },
    computed: {
        buttonInfo() {
            return {
                mode: 'book',
                buttonCaption: 'Update Personal Details',
                classType: 'book-button'
            }
        }
    },
    methods: {
        getDetails() {
            // API when ready
            this.userName = this.$store.getters.userName;
            this.memberName = this.$store.getters.memberName;
            this.emailAddress = this.$store.getters.emailAddress;
        },
        updateDetails() {
            if (this.userName !== '' && this.memberName !== '' && this.emailAddress !== '') {
                this.$store.dispatch('setUserDetails', {
                    userName: this.userName.trim(),
                    memberName: this.memberName.trim(),
                    emailAddress: this.emailAddress.trim()
                 })
            } else {
                // No details in one form field.
                this.formError = true;
            }
        }
    },  
    created() {
        this.getDetails();
    }
}
</script>

<style scoped>
.errorText {
    width: 100%;
    text-align: center;
    color: red;
    margin: 40px 0px;
}

#dashboardForm {
    margin-left: auto;
    margin-right: auto;
    min-width: 320px;
    max-width: 800px;
    padding: 20px;
}

#dashboardFormFooter{
    display: flex;
    justify-content: flex-end;
    padding: 20px;
}


.formControlGroup {
    display: flex;
    margin-bottom: 15px;
    justify-content: center;
    vertical-align: middle;
}

.formControlLabelContainer {
    width: 40%;
    padding-left: 10px;
    text-align: start;
}

.formControls {
    border-radius: 3px;
    font-size: 1.1rem;
    min-width: 200px;
    max-width: 300px;
}
.formControlInputContainer {

}
</style>