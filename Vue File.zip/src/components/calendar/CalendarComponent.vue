<template>
    <h2>Gym Class Calender</h2>
    <div id="calendar-outer-container">
        <div id="calendar-inner-container">
            <v-date-picker mode="date" v-model="selectedDate" :min-date="today" :max-date="lastDate" :attributes="attributes" is-expanded></v-date-picker>
        </div>
    </div>
</template>

<script>
import 'v-calendar/dist/style.css';
export default {
    props: ['today', 'lastDate', 'attributes'],
    emits: ['dateHasBeenSelected'],
    data() {
        return {
            selectedDate: null,
        }
    },
    watch: {
        selectedDate(newVal) {
            this.$emit('dateHasBeenSelected', newVal);
        }
    },
    methods: {

    }
}
</script>

<style scoped>
h2 {
    width:100%;
    text-align: center;    
}

.main-content {
    padding: 20px;
}

#calendar-outer-container {
    width: 100;
    display: flex;
    align-items: center;
    padding-bottom: 30px;
    padding-top: 20px;
}

#calendar-inner-container{
    width: 320px;
    align-self: center;
    margin-left: auto;
    margin-right: auto;
}

</style>