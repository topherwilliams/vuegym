<template>
    <div class="main-content">
        <div id="main-content-myDashboard">
            <div id="myDashboardPageHeader">
                <h2>My Dashboard</h2>
            </div>
            <div id="myDashboardMainContent">
                <AccountDashboard></AccountDashboard>
            </div>
        </div>
    </div>
</template>

<script>
import AccountDashboard from '../accountdashboard/AccountDashboard.vue';
export default {
    components: { 
        AccountDashboard 
    }
}
</script>

<style>
#myDashboardPageHeader {
    display: flex;
    align-items: center;
    justify-content: space-around;
    padding: 0 20px;
}

h2 {
    margin: 15px auto;
}
</style>