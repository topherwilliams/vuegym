<template>
    <div class="main-content">
        <h2>Vue Gym Class Search</h2>
        <div id="classSearch">
            <SearchOptions @commitSearch="searchClasses" :searchButtonInfo="searchButtonInfo"></SearchOptions>
        </div>
        <base-spinner :searching="searching"></base-spinner>
        <Transition name="dropDownElement">
            <div v-if="classesFound" id="main-content-classList">
                <!-- Expanded Class List components -->
                    <DetailedClassList :classes="alteredSearchResultClasses"></DetailedClassList>
            </div>
        </Transition>
        
    </div>
</template>

<script>
import DetailedClassList from '../classes/DetailedClassList.vue';
import SearchOptions from '../layouts/SearchOptions.vue';

export default {
    components: {
        DetailedClassList,
        SearchOptions,
    },
    computed: {
        searchResultClasses() {
            return [...this.$store.getters.returnUpcomingClasses];
        },
        alteredSearchResultClasses() {
            const alteredResults = [];
            this.searchResultClasses.forEach((classObject) => {
                alteredResults.push(
                    {
                        booking_id: null,
                        class_information: {
                            ...classObject
                        }
                    })
            })
            return alteredResults;
        },
        searchButtonInfo() {
            return {
                mode: 'book',
                buttonCaption: 'Search Classes',
                classType: 'book-button'
            }
        },
        classesFound() {
            if (this.alteredSearchResultClasses.length < 1) {
                return false;
            } return true;
        }
    },  
    data() {
        return {
            searching: false,
        }
    },
    methods: {
        searchClasses(searchTerms) {
            this.searching = true;
            setTimeout(() => {
                this.searching = false;
                this.$store.dispatch('populateFakeClasses'); //Update to API search.
                console.log(this.alteredSearchResultClasses);
            }, 2000);
            // TODO: API call to get classes

            console.log(searchTerms.className);            
        }
    },
}
</script>

<style scoped>
h2 {
    width:100%;
    text-align: center;    
}

#classSearch {
    display: flex;
    justify-content: center;
    margin: 15px 0px;
}

#classSearchForm {
    min-width: 320px;
    width: 1200px;
    padding: 20px;
    display: flex;
    flex-direction: column;
}

#classSearchFormFields {
    display: flex;
    flex-direction: row;
    justify-content: center;
    
}
.spinnerContainer{
    height: 100vh;
    width: 100vw;
    position: fixed;
    z-index: 500;
    top: 0;
    left: 0;
    /* width: 100%; */
    display: flex;
    justify-content: center;
    align-items: center;
}

.formControlGroup {
    margin-bottom: 10px;
    margin-left: 30px;
    margin-right: 30px;
    max-width: 50%;
    justify-content: center;
    vertical-align: middle; 
}

.formControlButton {
    align-self: center;
}

.formControls {
    border-radius: 3px;
    font-size: 1.1rem;
}

.formControlLabel{
    padding-right: 30px;
}


.dropDownElement-enter-from, .dropDownElement-leave-to {
    opacity: 0;
    transform: translateY(-30px);
}

.dropDownElement-enter-active, .dropDownElement-leave-active {
    transition: all 0.9s;
}

.dropDownElement-enter-to, .dropDownElement-leave-from {
    opacity: 1;
    transform: translateY(0px);
}



</style>