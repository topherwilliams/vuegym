<template>
    <div class="main-content">
        <div id="main-content-classList">
            <h2>My Class Schedule</h2>
            <!-- Expanded Class List components -->
            <DetailedClassList v-if="anyClassesBooked" :classes="myClassBookings"></DetailedClassList>
            <div id="bookingListError" v-else>
                <p>No Classes Currently Booked</p>
            </div>
        </div>
    </div>
</template>

<script>
import DetailedClassList from '../classes/DetailedClassList.vue';

export default {
    components: {
        DetailedClassList
    },
    computed: {
        anyClassesBooked() {
            if (this.myClassBookings.length < 1) {
                return false;
            } else {
                return true;
            }
        },
        myClassBookings() {
            return this.$store.getters.returnAllClassBookings;
        }
    },
    data() {
        return {
        }
    },
    methods: {
        async getMyClasses() {
            // Api call here to get current class list for user.
            // IMPORTANT - FOR CLASS SCHEDULE, THIS SHOULD SORT INTO DATE ORDER. NEWEST FIRST.
        },
        async cancelBooking(id) {
            console.log (`Cancelling booking for class ${id}`);
            // API call to cancel booking here
            this.getMyClasses(); //Refresh list of bookings from server.
        }
    },
    created() {
        this.getMyClasses();
    }
}
</script>

<style scoped>
h2 {
    width:100%;
    text-align: center;    
}

#bookingListError {
    display:flex;
    justify-content: center;
    color: red;
}
</style>