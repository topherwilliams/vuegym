<template>
    <div class="main-content">
        <div id="mainContentProgressTracker">
            <div id="progressPageHeader">
                <h2>Progress Tracker</h2>
            </div>
            <div id="progressExerciseSearch">
                <label for="exerciseSelection">Exercise Name: </label>
                <select v-model="exerciseName" name="exerciseSelection" id="exerciseSelection" class="formControls">
                    <option v-for="exercise in exerciseList" :key="exercise" :value="exercise">{{exercise}}</option>
                </select>
            </div>
            <div id="progressExerciseChart" v-if="exerciseTrackingAvailable">
                <LineChart :chartDataProp="chartData" :chartOptionProp="chartOptions"></LineChart>
            </div>
            <div id="exerciseChartError" v-else>
                <p>There is no data available for that exercise type.</p>
            </div>
        </div>
    </div>
</template>

<script>
import LineChart from '../charts/LineChart.vue';

export default {
    components: {
        LineChart
    },
    data() {
        return {
            exerciseName: '',
            exerciseTracking: [],
        }
    },
    computed: {
        exerciseTrackingAvailable() {
            return this.exerciseTrackingInfo.length < 1? false : true;
        },
        exerciseList() {
            return this.$store.getters.sortedExerciseList;
        },
        exerciseTrackingInfo() {
            return [...this.exerciseTracking];
        },
        reversedExerciseList() {
            return [...this.exerciseTracking].reverse();
        },
        chartDataLabels() {
            let dataLabels = [];
            let workoutCount = 1;
            this.reversedExerciseList.forEach(() => {
                // dataLabels.push(datapoint.exercise_id); 
                // In reality would probably refer to date this was logged or similar - worth updating in the backend?
                dataLabels.push(workoutCount);
                workoutCount ++;
            })
            return dataLabels;
        },
        chartDataPoints() {
            let dataPoints = [];
            this.reversedExerciseList.forEach((datapoint) => {
                dataPoints.push(datapoint.exercise_effort);
            })
            return dataPoints;
        },
        chartData() {
            return {
                labels: [...this.chartDataLabels],
                datasets: [{
                    label: this.exerciseName,
                    backgroundColor: '#000',
                    data: [...this.chartDataPoints]
                }],
            }        
        },
        chartOptions() {
            return {
                responsive: true,
                maintainAspectRatio: false,
                elements: {
                    line: {
                        tension: 0.2,
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Workout'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Total KG Lifted',

                        },
                        beginAtZero: true
                    }
                }
            }        
        }
    },
    watch: {
        exerciseName() {
            this.selectExercise();
        }
    },
    methods: {
        selectExercise() {
            if (this.exerciseName !== '') {
                this.exerciseTracking = [];
                let workoutInfo = this.$store.getters.reverseWorkoutList;
                let exerciseTrackingInfo = [];
                workoutInfo.forEach((element) => {
                    element.exercises.forEach((ele2) => {
                        if (ele2.exercise_name === this.exerciseName) {
                            exerciseTrackingInfo.push({
                                exercise_id: ele2.exercise_id,
                                exercise_effort: ele2.weight_kg * ele2.reps * ele2.sets
                            });
                        }
                    })
                })
                this.exerciseTracking = [...exerciseTrackingInfo];
            }
        }
    },
}
</script>

<style scoped>
#progressExerciseSearch {
    display: flex;
    justify-content: center;
    align-items: center;
}

#progressExerciseChart {
    margin-top: 10px;
    padding: 20px;
    display: flex;
    height: 400px;
}

#exerciseChartError{
    margin-top: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: red;
}

.formControls {
    border-radius: 3px;
    font-size: 1.1rem;
    margin: 0 15px;

}

h2 {
    margin: 15px auto;
    text-align: center;
}

.fas:hover {
    cursor: pointer;
    transform: scale(1.2);
}

.fas:active {
    transform: translateY(2px);
}

</style>