<template>
    <div class="main-content">
        <div id="main-content-workoutList">
            <div id="myWorkoutPageHeader">
                <h2>My Workouts</h2>
            </div>
            <div id="newWorkoutButtonContainer">
                    <base-button id="newWorkoutButton" :buttonInfo="newWorkoutButtonInfo" @click="addNewWorkout"></base-button>
            </div>
            <!-- Workout List Component Here which Includes List Items which can be edited / deleted. -->
            <base-spinner :searching="searching"></base-spinner>
            <DetailedWorkoutList @selectWorkout="selectWorkout" @deleteWorkout="deleteWorkout" :workouts="workoutList" :selectedWorkout="selectedWorkout"></DetailedWorkoutList>
            <EditWorkout @closeEditWorkout="clearSelectedWorkout" :workoutInfo="selectedWorkout"></EditWorkout>
        </div>
    </div>
</template>

<script>
import DetailedWorkoutList from '../workouts/DetailedWorkoutList.vue';
import EditWorkout from '../workouts/EditWorkout.vue';
export default {
    components: {
        DetailedWorkoutList,
        EditWorkout
    },
    data() {
        return {
            selectedWorkout: null,
            searching: false,
        }
    },
    computed: {
        newWorkoutButtonInfo() {
            return {
                buttonCaption: 'Add New Workout',
                classType: 'book-button',
                buttonId: 1,
            }
        },
        pageHeading() {
            if (!this.selectedWorkout) {
                return 'My Workouts'
            } else {
                return `Edit Workout ${this.selectedWorkout.workout_id}`;
            }
        },
        workoutList() {
            return [...this.$store.getters.reverseWorkoutList];
        },
    },
    methods: {
        addNewWorkout() {
            this.$store.dispatch('createNewWorkout');
            this.clearSelectedWorkout();
        },
        deleteWorkout(id) {
            this.$store.dispatch('deleteWorkout', id);
            this.clearSelectedWorkout();
        },
        selectWorkout(id) {
            if (this.selectedWorkout) {
                this.clearSelectedWorkout();
            } else {
                const tempWorkout = this.workoutList.filter((workout) => {
                    if(workout.workout_id === id) {
                        return true;
                    }
                })
                this.selectedWorkout = tempWorkout[0];
            }
        },
        clearSelectedWorkout() {
            this.selectedWorkout = null;
        },
        async updateWorkoutList() {
            // Once hooked up - call API here.
            this.searching = true;
            setTimeout(() => {
                this.searching = false;
                this.$store.dispatch('updateWorkoutList');
            }, 2000);
        }
    },
    created() {
        this.updateWorkoutList();
    }
}
</script>

<style scoped>
#newWorkoutButtonContainer {
    width: 100%;
    margin: auto;
    display: flex;
    justify-content: center;
    align-items: center;
}

#myWorkoutPageHeader {
    display: flex;
    align-items: center;
    justify-content: space-around;
    padding: 0 20px;
}

#newWorkoutButton {
    margin: 5px 0;
}

h2 {
    margin: 15px auto;
}

</style>