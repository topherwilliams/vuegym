<template>
    <div class="main-content">
        <div id="main-content-calendar">
            <!-- TODO: Any way of having classes only search for 'current month' in the vcalendar view to save data?? -->
            <CalendarComponent :today="today" :lastDate="lastDate" :attributes="classDatesForCalendar" @dateHasBeenSelected="updateTargetDate"></CalendarComponent>
        </div>
        <div id="main-content-classlist">
            <transition name="dropDownElement">
                <ClassList @selectClass="selectClass" v-if="targetDateClassesAvailable" :targetDate="targetDate" :targetDateFormatted="targetDateFormatted" :classes="targetDateClasses"></ClassList>
            </transition>
        </div>
        <div id="main-content-classDetails">
            <transition name="dropDownElement">
                <ClassInformation v-if="targetClassId" :classInfo="targetClassInformation" :bookingInfo="targetClassBooking"></ClassInformation>
            </transition>
        </div>
    </div>
</template>

<script>
import CalendarComponent from '../calendar/CalendarComponent.vue'
import ClassList from '../classes/ClassList.vue';
import ClassInformation from '../classes/ClassInformation.vue';

export default {
    components: {
        CalendarComponent,
        ClassList,
        ClassInformation,
    },
    data() {
        return {
            targetDate: null,
            targetClassId: null,
            targetClassBooking: null,
        }
    },
    computed: {
        upcomingClasses() {
            return [...this.$store.getters.returnUpcomingClasses];
        },
        targetClassInformation() {
            const classObject = this.upcomingClasses.filter(classObj => 
                classObj.class_id === this.targetClassId
            )
            return classObject;
        },
        targetDateFormatted() {
            const date = new Date(this.targetDate);
            return date.toLocaleDateString("en-UK", {
                day: "numeric",
                month: "long",
                year: "numeric",
                weekday: "long"
            })
        },  
        classDatesForCalendar() {
            let attributeData = [{
                key: 'dates',
                highlight: true,
                dates: [...this.uniqueClassDatesCalendarFormat]
            }]
            return attributeData;
        },
        uniqueClassDatesCalendarFormat() {
            return this.filterForUniqueDates('calendar', this.upcomingClasses);
        },
        uniqueClassDates() {
            return this.filterForUniqueDates('basic', this.upcomingClasses);
        },
        targetDateClasses() {
            let classesOnTargetDate = [];
            this.upcomingClasses.forEach((classEle) => {
                if (classEle.class_date === this.targetDate) {
                    classesOnTargetDate.push(classEle);
                }
            })
            return classesOnTargetDate;
        },
        targetDateClassesAvailable() {
            if (this.targetDateClasses.length < 1) {
                return false;
            } else {
                return true;
            }
        },  
        today() {
            return new Date();
        },
        lastDate() {
            // return new Date();
            if (!this.upcomingClasses || this.uniqueClassDates.length < 1) {
                return new Date();
            } else {
                return new Date(Math.max.apply(null, this.uniqueClassDatesCalendarFormat));
            }
        }
    },
    methods: {
        selectClass(classID) {
            this.targetClassId = classID;
            this.checkBooking(classID);
        },
        checkBooking(id) {
            // Once hooking up to API, this will be done via API call.
            this.targetClassBooking = {
                class_id: id,
                member_id: 1,
            };
        },
        filterForUniqueDates(format, array) {
            let uniqueDates = array.reduce((acc, current) => {
                let formattedDate = format === 'calendar'? this.convertBasicDateToCalendarFormat(current.class_date) : current.class_date;
                if (!acc.includes(formattedDate)) {
                    acc.push(formattedDate);
                }
                return acc;
            }, []);
            return uniqueDates;
        },
        updateTargetDate(newDate) {
            this.targetClassId = null;
            let tempDate = new Date(newDate);
            let formattedDate = tempDate.toISOString().substring(0,10);
            if (formattedDate === "1970-01-01") {
                this.targetDate = null;
            } else {
                this.targetDate = formattedDate;
            }
        },
        convertBasicDateToCalendarFormat(basicDate) {
            return new Date(basicDate);
        },
        convertCalendarDateToBasicFormat(calendarDate) {
            let tempDate = new Date(calendarDate);
            return tempDate.toISOString().substring(0,10);
        },
    },
    created() {
        // Update list of classes - replace with API call.
        this.$store.dispatch('populateFakeClasses');
    }
}
</script>

<style scoped>
.section-content {
    padding: 20px;
}

.dropDownElement-enter-from, .dropDownElement-leave-to {
    opacity: 0;
    transform: translateY(-30px);
}

.dropDownElement-enter-active, .dropDownElement-leave-active {
    transition: all 0.9s;
}

.dropDownElement-enter-to, .dropDownElement-leave-from {
    opacity: 1;
    transform: translateY(0px);
}

</style>