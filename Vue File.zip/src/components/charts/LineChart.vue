<template>
    <Line
    id="exerciseChart"
    :options="chartOptionProp"
    :data="chartDataProp"
    />
</template>

<script>
import { Line } from 'vue-chartjs'
import {Chart as ChartJS, Title, Legend, LineElement, PointElement, CategoryScale, LinearScale} from 'chart.js';
ChartJS.register(Title, Legend, PointElement, LineElement, CategoryScale, LinearScale);

export default {
    name: 'LineChart',
    components: {
        Line
    },
    props: ['chartDataProp', 'chartOptionProp'],
}
</script>

<style>
</style>