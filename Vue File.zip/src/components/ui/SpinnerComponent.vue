<template>
    <Teleport to="body">
        <div v-if="searching" class="spinnerContainer">
            <Transition name="spinnerAppear" appear>
                <img v-if="searching" id="spinner" src="../../assets/spinner/c6abe1d0-2bbf-4f57-ade7-bb98cc14189c.svg" alt=""/>
            </Transition>
        </div>
    </Teleport>    
</template>

<script>
export default {
    props: ['searching'],
}
</script>

<style scoped>
.spinnerContainer{
    height: 100vh;
    width: 100vw;
    position: fixed;
    top: 0;
    left: 0;
    background-color: white;
    opacity: 75%;
    z-index: 500;
    display: flex;
    justify-content: center;
    align-items: center;
}

#spinner {
    z-index: 999;
}

.spinnerAppear-enter-from {
    opacity: 0;
    transform: scale(0.3);
}

.spinnerAppear-enter-active, .spinnerAppear-leave-active {
    transition: all 0.5s;
}

.spinnerAppear-enter-to, .spinnerAppear-leave-from {
    opacity: 1;
    transform: scale(1);
}

.spinnerAppear-leave-to {
    opacity: 0;
    transform: scale(10);
}


</style>