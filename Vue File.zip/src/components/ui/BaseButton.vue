<template>
    <a @click.prevent="confirmAction" :class="classType" >{{ buttonCaption }}</a>
</template>

<script>

export default {
    // Pretty sure this can be component-ised even further to accept props rather than logic here.
    props: ['buttonInfo',],
    computed: {
        buttonCaption() {
            return this.buttonInfo.buttonCaption;
        },
        classType() {
            return this.buttonInfo.classType;
        },
        buttonFunction() {
            return this.buttonInfo.buttonFunction;
        } 
    },
    methods: {
        confirmAction() {
            this.$emit('confirmAction', this.buttonInfo.id);
        }
    }
}
</script>

<style scoped>
a {
    border: 1px solid black;
    border-radius: 8px;
    padding: 12px;
}

a:hover {
    cursor: pointer;
}

.cancel-button {
    background-color: lightcoral;
}

.book-button {
    background-color: lightgreen;
}

</style>