export default {
    state() {
        return {
            gymExerciseList: ['Assisted Chin Ups', 'Bicep Curls', 'Bench Press', 'Assisted Tricep Dips', 'Tricep Extensions', 'Squats', 'Push Ups', 'Seated Row', 'Chest Fly', 'Swimmers Press', 'Pull Ups', 'Tricep Dips', 'Shoulder Press'],
            upcomingClasses: []
        }
    },
    mutations: {
        updateUpcomingClassListBulk(state, payload) {
            const templist = [...payload];
            state.upcomingClasses = templist;
        }
    },
    getters: {
        sortedExerciseList(state) {
            return [...state.gymExerciseList.sort()];
        },
        unsortedExerciseList(state) {
            return [...state.gymExerciseList];
        },
        returnUpcomingClasses(state) {
            return [...state.upcomingClasses];
        }
    },
    actions: {
        populateFakeClasses(context) {
            const tempClassList = [
                {
                    class_id: 1,
                    class_name: 'Cycling',
                    class_duration: 60,
                    class_capacity: 20,
                    class_booked_spaces: 5,
                    class_date: "2023-03-20",
                    class_instructor: {
                        instructor_id: 1,
                        instructor_name: 'Bobby Whistle'
                    }
                },
                {
                    class_id: 2,
                    class_name: 'WeightLifting',
                    class_duration: 60,
                    class_capacity: 20,
                    class_booked_spaces: 0,
                    class_date: "2023-03-30",
                    class_instructor: {
                        instructor_id: 1,
                        instructor_name: 'Jerry Iron'
                    }
                },
                {
                    class_id: 3,
                    class_name: 'Step Aerobics',
                    class_duration: 60,
                    class_capacity: 20,
                    class_booked_spaces: 18,
                    class_date: "2023-03-20",
                    class_instructor: {
                        instructor_id: 1,
                        instructor_name: 'Bobby Whistle'
                    }
                },
                {
                    class_id: 4,
                    class_name: 'Cycling',
                    class_duration: 60,
                    class_capacity: 20,
                    class_booked_spaces: 5,
                    class_date: "2023-04-01",
                    class_instructor: {
                        instructor_id: 1,
                        instructor_name: 'Bobby Whistle'
                    }
                },
            ]
            context.commit('updateUpcomingClassListBulk', tempClassList)
        }
    }
}