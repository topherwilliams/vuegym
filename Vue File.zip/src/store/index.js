import { createStore } from  'vuex';
import Gym from './gym.js';
import workouts from './workouts.js';
import bookings from './bookings.js';

// TODO: Might make sense to split out future bookings into another store to manage - computed list of just class IDs etc.
const store = createStore({
    modules: {
        Gym,
        workouts,
        bookings
    },
    state() {
        return {
            userID: 1,
            emailAddress: 'email_one@email.com',
            userName: 'username1',
            memberName: 'Member One',
            authToken: null,
            currentlyOnline: true,
        }
    },
    mutations: {
        setUserState(state, payload) {
            state.userID = payload.userId;
            state.emailAddress = payload.emailAddress;
            state.userName = payload.userName;
            state.memberName = payload.memberName;
            state.authToken = payload.authToken;
        },
        setUserStateLimited(state, payload) {
            state.emailAddress = payload.emailAddress;
            state.userName = payload.userName;
            state.memberName = payload.memberName;
        },
        clearUserState(state) {
            state.userID = null;
            state.emailAddress = null;
            state.userName = null;
            state.memberName = null;
            state.authToken = null;
        },
    },
    actions: {
        //Auth functions here - sign in and sign out.
        setUserDetails(context, payload) {
            context.commit('setUserStateLimited', payload);
        }
    },
    getters: {
        userId(state) {
            return state.userID;
        },
        emailAddress(state) {
            return state.emailAddress;
        },
        userName(state) {
            return state.userName;
        },
        memberName(state) {
            return state.memberName;
        },
        authToken(state) {
            return state.authToken;
        },
    }
});

export default store;