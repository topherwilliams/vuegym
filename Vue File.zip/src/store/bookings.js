// User's class bookings
export default {
    state() {
        return {
            myclassbookings: []
        }
    },
    mutations: {
        addBooking(state, payload) {
            // Call to API and then update booked classes.
            const newBookingArray = [...state.myclassbookings];
            newBookingArray.push(payload);
            state.myclassbookings = newBookingArray;
        },
        cancelBooking(state, payload) {
            const newBookingArray = [...state.myclassbookings.filter((booking) => {
                if(booking.booking_id !== payload) {
                    return true;
                }
            })];
            state.myclassbookings = newBookingArray;
        }
    },
    getters: {
        returnAllClassBookings(state) {
            return [...state.myclassbookings];
        },
    },
    actions: {
        async updateBookedClasses() {
            // TODO API call to get actual list of booked classes.
        },
        cancelClassBookingByBookingID(context, payload) {
            // TODO API call and then update booking array
            context.commit('cancelBooking', payload);
        },
        cancelClassBookingByClassID(context, payload) {
            const bookings = [...context.getters.returnAllClassBookings.filter((booking) => {
                return booking.class_information.class_id === payload? true: false;
            })]
            if (bookings.length > 0) {
                context.commit('cancelBooking', bookings[0].booking_id);
            }
        },
        async bookClass(context, payload) {
            // For when API works
            // if(navigator.onLine) {
            //     // i.e. only do the API call if online
            //     if (context.state.userID) { // do check here on whether token exists when built
            //         console.log(`Store: Booking class with ID of ${payload.id}`);
            //         const res = await fetch(`http://localhost:8080/classbooking/create/${context.state.userID}`, {
            //             method: 'POST',
            //             body: JSON.stringify({class_id: payload.id}),
            //             headers: {
            //                 // 'Content-Type': 'application/json',
            //                 'Authorization': JSON.stringify({'email_address' : context.state.emailAddress,
            //                 'password': context.state.password})
            //             }
            //         });
            //         const responseData = await res.json();
            //         if (!res.ok) {
            //             const error = new Error(responseData.message || 'Failed to authenticate');
            //             throw error;
            //         }
            //         console.log(responseData);
            //         console.log(responseData.length());
            //     } else {
            //         // online but no token saved in memory - tell user to sign out and sign in again.
            //     }
            // } else {
            //     // Handle if user is offline - suggestion is a banner at the bottom that confirms offline - cached data is being used if available. 
            // }
            // Will be more straightforward with the API.
            const classes = [...context.getters.returnUpcomingClasses.filter((classObj) => {
                return classObj.class_id === payload? true: false;
            })];
            const bookingObject = {
                booking_id: new Date().toISOString(),
                class_information: {
                    class_id: classes[0].class_id,
                    class_name: classes[0].class_name,
                    class_duration: classes[0].class_duration,
                    class_capacity: classes[0].class_capacity,
                    class_booked_spaces: classes[0].class_booked_spaces + 1,
                    class_date: classes[0].class_date,
                    class_instructor: {
                        instructor_id: classes[0].class_instructor.instructor_id,
                        instructor_name: classes[0].class_instructor.instructor_name
                    }
                }
            }
            context.commit('addBooking', bookingObject);

        },
    }
}