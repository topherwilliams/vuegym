export default {
    state() {
        return {
            workouts: []
        }
    },
    mutations: {
        sortWorkouts(state) {
            let updatedList = state.workoutList;
            updatedList.sort((a, b) => {
                return a.workout_id.localeCompare(b.workout_id);
            })
            state.workouts = [...updatedList];
        },
        updateWorkouts(state, payload) {
            state.workouts = [...payload];
        },
        updateWorkoutDetails(state, payload) {
            // create a new list without target workout ID and then update with updated object
            // Two ways of doing - filter works but 'loses' the order 
            const updatedList = state.workouts.filter((workout) => {
                if(workout.workout_id !== payload.workout_id) {
                    return true;
                }
            });
            updatedList.push(payload);
            state.workouts = [...updatedList];
            this.sortWorkouts();
        },
        addNewWorkout(state, payload) {
            state.workouts.push(payload);
        },
        deleteWorkout(state, payload) {
            const updatedList = state.workouts.filter((workout) => {
                if(workout.workout_id !== payload) {
                    return true;
                }
            });
            state.workouts = [...updatedList];
        }
    },
    getters: {
        workoutList(state) {
            return [...state.workouts];
        },
        reverseWorkoutList(state) {
            return [...state.workouts.reverse()];
        },
    },
    actions: {
        getExerciseInfoFromWorkouts(context, payload) {
            const exerciseTrackingInfo = [];
            const tempWorkoutList = [...this.reverseWorkoutList];
            tempWorkoutList.forEach((element) => {
                element.exercises.forEach((ele2) => {
                    if (ele2.exercise_name === payload) {
                        exerciseTrackingInfo.push(ele2);
                    }
                })
            })
            return exerciseTrackingInfo;
        },
        async createNewWorkout(context) {
            //API Call here to create new workout
            // Handle by going to the new one.
            const tempID = new Date().toISOString();
            const tempNewWorkout = {
                workout_id: tempID,
                member: {
                    member_id: 3,
                    member_email_address: 'no@no.com',
                    member_username: 'You',
                    member_name: 'Barry'
                },
                exercises: [],
            };
            context.commit('addNewWorkout', tempNewWorkout)
        },
        updateWorkout(context, payload) {
            context.commit('updateWorkoutDetails', payload);
        },
        async updateWorkoutList(context) {
            // API Call here.
            console.log("Updating fake workouts");
            const fakeWorkouts = [
                {
                    workout_id: 1,
                    member: {
                        member_id: 3,
                        member_email_address: 'no@no.com',
                        member_username: 'You',
                        member_name: 'Barry'
                    },
                    exercises: [
                        {
                            exercise_id: 1,
                            exercise_name: 'Bicep Curls',
                            weight_kg: 20,
                            reps: 10,
                            sets: 3
                        },
                        {
                            exercise_id: 2,
                            exercise_name: 'Shoulder Press',
                            weight_kg: 20,
                            reps: 10,
                            sets: 3
                        },
                        {
                            exercise_id: 3,
                            exercise_name: 'Tricep Dips',
                            weight_kg: 25,
                            reps: 12,
                            sets: 3
                        },
                    ]
                }, {
                    workout_id: 2,
                    member: {
                        member_id: 3,
                        member_email_address: 'no@no.com',
                        member_username: 'You',
                        member_name: 'Barry'
                    },
                    exercises: [
                        {
                            exercise_id: 4,
                            exercise_name: 'Tricep Dips',
                            weight_kg: 20,
                            reps: 10,
                            sets: 3
                        },
                        {
                            exercise_id: 5,
                            exercise_name: 'Bench Press',
                            weight_kg: 20,
                            reps: 10,
                            sets: 3
                        },
                    ]
                },
                {
                    workout_id: 3,
                    member: {
                        member_id: 3,
                        member_email_address: 'no@no.com',
                        member_username: 'You',
                        member_name: 'Barry'
                    },
                    exercises: [
                        {
                            exercise_id: 6,
                            exercise_name: 'Tricep Dips',
                            weight_kg: 20,
                            reps: 10,
                            sets: 3
                        },
                    ]
                },
                {
                    workout_id: 4,
                    member: {
                        member_id: 3,
                        member_email_address: 'no@no.com',
                        member_username: 'You',
                        member_name: 'Barry'
                    },
                    exercises: [
                        {
                            exercise_id: 7,
                            exercise_name: 'Tricep Dips',
                            weight_kg: 30,
                            reps: 12,
                            sets: 3
                        },
                    ]
                }
            ];
            context.commit('updateWorkouts', fakeWorkouts);
        },
        deleteWorkout(context, payload) {
            context.commit('deleteWorkout', payload);
        }
    }
}